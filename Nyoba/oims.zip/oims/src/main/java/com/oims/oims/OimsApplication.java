package com.oims.oims;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OimsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OimsApplication.class, args);
	}
}
